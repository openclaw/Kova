# Kova OpenClaw Runtime Report

> **❌ [FAIL]** — runtime-management peak RSS 1053.3 MB exceeded threshold 900 MB

## Verdict

| Field | Value |
|---|---|
| Verdict | FAIL |
| Reason | runtime-management peak RSS 1053.3 MB exceeded threshold 900 MB |
| Blocking findings | 10 |
| Warnings | 0 |
| Records | 10 (FAIL:5, PASS:5) |

## Proof Completeness

- Completeness: complete: 10
- Required obligations: 150 total, 0 missing, 1 failed
- Categories: command: 88, invariant: 42, artifact: 10, cleanup: 10

| Scenario | Obligation | Status | Reason |
|---|---|---|---|
| openai-compatible-turn | command:openai-compatible-turn:1 | failed | command exited 1 |

## Run

| Field | Value |
|---|---|
| Run ID | `kova-2026-05-18T094832Z` |
| Generated | 2026-05-18T09:50:53.626Z |
| Mode | execution |
| Target | `npm:2026.5.16-beta.7` |
| Platform | darwin 25.3.0 (arm64) · v24.13.0 |
| Repeat / parallel | 1 / 1 |
| Auth | unknown |

## Coverage

| Field | Value |
|---|---:|
| Records | 10 |
| Scenarios | 10 |
| States | 5 |
| FAIL | 5 |
| PASS | 5 |

## Findings

| Severity | Area | Scenario | Finding | Evidence |
|---|---|---|---|---|
| fail | OpenClaw | release-runtime-startup/fresh | runtime-management peak RSS 1053.3 MB exceeded threshold 900 MB | readinessHealthReadyMs: 2734; readinessListeningMs: 2534 |
| fail | OpenClaw | release-runtime-startup/fresh | package-manager peak RSS 1053.3 MB exceeded threshold 900 MB | readinessHealthReadyMs: 2734; readinessListeningMs: 2534 |
| fail | OpenClaw | fresh-install/fresh | peak RSS 1074.1 MB exceeded threshold 900 MB | readinessHealthReadyMs: 1805; readinessListeningMs: 1764 |
| diagnostic-gap | OpenClaw | fresh-install/fresh | 3 expected OpenClaw diagnostics span(s) were not observed; user-path verdict is based on functional and performance checks | missing spans: gateway.startup, plugins.metadata, providers.list |
| diagnostic-gap | OpenClaw | bundled-runtime-deps/missing-plugin-index | 3 expected OpenClaw diagnostics span(s) were not observed; user-path verdict is based on functional and performance checks | missing spans: runtimeDeps.stage, plugins.runtimeDeps, plugins.runtimeDeps.install |
| diagnostic-gap | OpenClaw | plugin-lifecycle/stale-runtime-deps | 2 expected OpenClaw diagnostics span(s) were not observed; user-path verdict is based on functional and performance checks | missing spans: plugins.registry.refresh, plugins.update |
| diagnostic-gap | OpenClaw | bundled-plugin-startup/fresh | 2 expected OpenClaw diagnostics span(s) were not observed; user-path verdict is based on functional and performance checks | missing spans: plugins.metadata, plugins.runtimeDeps |
| fail | OpenClaw | gateway-performance/many-bundled-plugins | peak RSS 1025.6 MB exceeded threshold 900 MB | readinessHealthReadyMs: 1602; readinessListeningMs: 1513 |
| diagnostic-gap | OpenClaw | gateway-performance/many-bundled-plugins | 3 expected OpenClaw diagnostics span(s) were not observed; user-path verdict is based on functional and performance checks | missing spans: gateway.startup, health.ready, eventLoop.delay |
| fail | OpenClaw | agent-gateway-rpc-turn/mock-openai-provider | gateway-rpc pre-provider work dominated agent turn (96% of 2963ms) | readinessHealthReadyMs: 2155; readinessListeningMs: 2018 |
| fail | OpenClaw | openai-compatible-turn/mock-openai-provider | agent message command finished without a usable assistant response | readinessHealthReadyMs: 2093; readinessListeningMs: 2017 |
| fail | OpenClaw | openai-compatible-turn/mock-openai-provider | openai-compatible agent turn did not produce the expected assistant response | readinessHealthReadyMs: 2093; readinessListeningMs: 2017 |
| info | Kova | report | 4 additional finding(s) omitted from Markdown | see summary JSON |

## Performance Summary

| Scenario | Samples | Status | Health Ready | Gateway RSS | Peak RSS | CPU | Cold Turn | Warm Turn | Cold Pre-Provider |
|---|---:|---|---:|---:|---:|---:|---:|---:|---:|
| release-runtime-startup/fresh | 1 | FAIL:1 | 2734ms | 589.5MB | 589.5MB | 93.5% | unknown | unknown | unknown |
| fresh-install/fresh | 1 | FAIL:1 | 1805ms | 630.4MB | 1074.1MB | 226.1% | unknown | unknown | unknown |
| bundled-runtime-deps/missing-plugin-index | 1 | PASS:1 | 1851ms | 581MB | 583MB | 49.6% | unknown | unknown | unknown |
| plugin-lifecycle/stale-runtime-deps | 1 | PASS:1 | 608ms | 585.9MB | 587.9MB | 117.5% | unknown | unknown | unknown |
| bundled-plugin-startup/fresh | 1 | PASS:1 | 2ms | 610MB | 611.9MB | 119.6% | unknown | unknown | unknown |
| gateway-performance/many-bundled-plugins | 1 | FAIL:1 | 1602ms | 585.6MB | 1025.6MB | 150% | unknown | unknown | unknown |
| agent-cold-warm-message/mock-openai-provider | 1 | PASS:1 | unknown | 0MB | 639.2MB | 118.2% | 4009ms | 3560ms | 3824ms |
| agent-gateway-rpc-turn/mock-openai-provider | 1 | FAIL:1 | 2155ms | 610.9MB | 571.1MB | 127.1% | 2963ms | unknown | 2852ms |
| gateway-session-send-turn/mock-openai-provider | 1 | PASS:1 | 1948ms | unknown | 694.2MB | 102.1% | 2168ms | 1231ms | 1633ms |
| openai-compatible-turn/mock-openai-provider | 1 | FAIL:1 | 2093ms | 601.3MB | 602.1MB | 103.4% | 84ms | unknown | unknown |

## Samples

| Sample | Status | Scenario | Health Ready | Gateway RSS | Peak RSS | Cold Turn | Warm Turn | Blocker |
|---:|---|---|---:|---:|---:|---:|---:|---|
| 1 | FAIL | release-runtime-startup/fresh | 2734ms | 589.5 MB | 589.5 MB | unknown | unknown | runtime-management peak RSS 1053.3 MB exceeded threshold 900 MB |
| 1 | FAIL | fresh-install/fresh | 1805ms | 630.4 MB | 1074.1 MB | unknown | unknown | peak RSS 1074.1 MB exceeded threshold 900 MB |
| 1 | PASS | bundled-runtime-deps/missing-plugin-index | 1851ms | 581 MB | 583 MB | unknown | unknown |  |
| 1 | PASS | plugin-lifecycle/stale-runtime-deps | 608ms | 585.9 MB | 587.9 MB | unknown | unknown |  |
| 1 | PASS | bundled-plugin-startup/fresh | 2ms | 610 MB | 611.9 MB | unknown | unknown |  |
| 1 | FAIL | gateway-performance/many-bundled-plugins | 1602ms | 585.6 MB | 1025.6 MB | unknown | unknown | peak RSS 1025.6 MB exceeded threshold 900 MB |
| 1 | PASS | agent-cold-warm-message/mock-openai-provider | unknown | 0 MB | 639.2 MB | 4009ms | 3560ms |  |
| 1 | FAIL | agent-gateway-rpc-turn/mock-openai-provider | 2155ms | 610.9 MB | 571.1 MB | 2963ms | unknown | gateway-rpc pre-provider work dominated agent turn (96% of 2963ms) |
| 1 | PASS | gateway-session-send-turn/mock-openai-provider | 1948ms | 694.2 MB | 694.2 MB | 2168ms | 1231ms |  |
| 1 | FAIL | openai-compatible-turn/mock-openai-provider | 2093ms | 601.3 MB | 602.1 MB | 84ms | unknown | agent message command finished without a usable assistant response |

## Resource Roles

- command-tree: RSS 1202.4 MB; CPU 312.6%; scenario release-runtime-startup/fresh
- package-manager: RSS 1053.3 MB; CPU 312.6%; scenario release-runtime-startup/fresh
- runtime-management: RSS 1053.3 MB; CPU 312.6%; scenario release-runtime-startup/fresh
- gateway: RSS 694.2 MB; CPU 119.7%; scenario gateway-session-send-turn/mock-openai-provider
- gateway-tree: RSS 694.2 MB; CPU 119.7%; scenario gateway-session-send-turn/mock-openai-provider
- agent-cli: RSS 639.2 MB; CPU 127.1%; scenario agent-cold-warm-message/mock-openai-provider
- agent-process: RSS 639.2 MB; CPU 127.1%; scenario agent-cold-warm-message/mock-openai-provider
- status-cli: RSS 462.2 MB; CPU 100.6%; scenario release-runtime-startup/fresh

## Selected Sample Details

### release-runtime-startup sample 1

- Status: FAIL
- Cleanup: destroyed
- Artifact root: /Users/shakker/.kova/artifacts/kova-2026-05-18T094832Z/kova-release-runtime-startup-fresh-kova-2026-05-18t094832z
Measurements:
- startup: listening 2534ms; health 2734ms; readiness ready; gateway running; restarts 1
- health: startup p95 200ms; post-ready p95 4ms; failures 10; final failures 0; slowest startup-sample/provision 200ms
- resources: peak RSS 589.5 MB; max CPU 93.5%; samples 23; roles command-tree 1202.4MB/312.6%, package-manager 1053.3MB/312.6%, runtime-management 1053.3MB/312.6%, gateway 589.5MB/93.5%
- agent: turn not-run; cold/warm unknown/unknown; cold-warm delta unknown; pre-provider unknown; provider unknown; metadata scans 0 (0ms); event-loop unknown; polls 0; cleanup unknown; diagnosis unknown; leaks 0
- Agent turn stats: count 0; p95 unknown; max unknown; pre-provider p95 unknown
- plugins/runtime: missing deps 0; plugin failures 0; runtime deps unknown; warm restages unknown; warm reuse unknown
- diagnostics: timeline available; slowest span gateway.ready 254.89ms; embedded traces 0; liveness warnings 0; open spans 0 (0 required); node CPU/heap/trace 0/0/0
- Violations:
  - runtime-management peak RSS 1053.3 MB exceeded threshold 900 MB
  - package-manager peak RSS 1053.3 MB exceeded threshold 900 MB

### fresh-install sample 1

- Status: FAIL
- Cleanup: destroyed
- Artifact root: /Users/shakker/.kova/artifacts/kova-2026-05-18T094832Z/kova-fresh-install-fresh-kova-2026-05-18t094832z
Measurements:
- startup: listening 1764ms; health 1805ms; readiness ready; gateway running; restarts 5
- health: startup p95 41ms; post-ready p95 4ms; failures 13; final failures 0; slowest startup-sample/provision 41ms
- resources: peak RSS 1074.1 MB; max CPU 226.1%; samples 17; roles gateway 630.4MB/119.7%, gateway-tree 630.4MB/119.7%, command-tree 443.7MB/106.4%, status-cli 443.7MB/92.3%
- agent: turn not-run; cold/warm unknown/unknown; cold-warm delta unknown; pre-provider unknown; provider unknown; metadata scans 0 (0ms); event-loop unknown; polls 0; cleanup unknown; diagnosis unknown; leaks 0
- Agent turn stats: count 0; p95 unknown; max unknown; pre-provider p95 unknown
- plugins/runtime: missing deps 0; plugin failures 0; runtime deps unknown; warm restages unknown; warm reuse unknown
- diagnostics: timeline available; slowest span gateway.ready 325.76ms; embedded traces 0; liveness warnings 0; open spans 0 (0 required); node CPU/heap/trace 0/0/0
- Violations:
  - peak RSS 1074.1 MB exceeded threshold 900 MB

### gateway-performance sample 1

- Status: FAIL
- Cleanup: destroyed
- Artifact root: /Users/shakker/.kova/artifacts/kova-2026-05-18T094832Z/kova-gateway-performance-many-bundled-plugins-kova-2026-05-18t094832z
Measurements:
- startup: listening 1513ms; health 1602ms; readiness ready; gateway running; restarts 6
- health: startup p95 89ms; post-ready p95 3ms; failures 6; final failures 0; slowest startup-sample/cold-start 89ms
- resources: peak RSS 1025.6 MB; max CPU 150%; samples 16; roles gateway 585.6MB/57.6%, gateway-tree 585.6MB/57.6%, command-tree 440.5MB/92.4%, status-cli 440.5MB/92.4%
- agent: turn not-run; cold/warm unknown/unknown; cold-warm delta unknown; pre-provider unknown; provider unknown; metadata scans 0 (0ms); event-loop unknown; polls 0; cleanup unknown; diagnosis unknown; leaks 0
- Agent turn stats: count 0; p95 unknown; max unknown; pre-provider p95 unknown
- plugins/runtime: missing deps 0; plugin failures 0; runtime deps unknown; warm restages 0; warm reuse true
- diagnostics: timeline available; slowest span gateway.ready 258.98ms; embedded traces 0; liveness warnings 0; open spans 0 (0 required); node CPU/heap/trace 0/0/0
- Violations:
  - peak RSS 1025.6 MB exceeded threshold 900 MB

### agent-cold-warm-message sample 1

- Status: PASS
- Cleanup: destroyed
- Artifact root: /Users/shakker/.kova/artifacts/kova-2026-05-18T094832Z/kova-agent-cold-warm-message-mock-openai-provider-kova-2026-05-18t094832z
Measurements:
- startup: listening unknown; health unknown; readiness unknown; gateway disabled; restarts 0
- health: startup p95 unknown; post-ready p95 unknown; failures 0; final failures 0
- resources: peak RSS 639.2 MB; max CPU 118.2%; samples 13; roles agent-cli 639.2MB/118.2%, agent-process 639.2MB/118.2%, command-tree 639.2MB/118.2%, status-cli 443MB/94.9%
- agent: turn 4009ms; cold/warm 4009ms/3560ms; cold-warm delta 449ms; pre-provider 3824ms; provider 1ms; metadata scans 26 (1049.66ms); event-loop unknown; polls 0; cleanup unknown; diagnosis agent-latency-attributed; leaks 0
- Agent turn stats: count 2; p95 3986.55ms; max 4009ms; pre-provider p95 3805.25ms
- agent CLI attribution: cold known 550ms / unattributed 3274ms; warm known 507ms / unattributed 2942ms
- plugins/runtime: missing deps 0; plugin failures 0; runtime deps unknown; warm restages unknown; warm reuse unknown
- diagnostics: timeline available; slowest span plugins.metadata.scan 58.83ms; embedded traces 0; liveness warnings 0; open spans 0 (0 required); node CPU/heap/trace 0/0/0
- Agent turns:
  - cold: total 4009ms; pre-provider 3824ms; provider 1ms; post-provider 184ms; response true
    - active window: metadata scans 13 (546.46ms total, max 56.17ms); event-loop samples 0 max unknown
    - breakdown: pre-provider 3824ms; provider 1ms; post-provider 184ms; unknown 3824ms; source none
  - warm: total 3560ms; pre-provider 3449ms; provider 0ms; post-provider 111ms; response true
    - active window: metadata scans 13 (503.2ms total, max 57.43ms); event-loop samples 0 max unknown
    - breakdown: pre-provider 3449ms; provider 0ms; post-provider 111ms; unknown 3449ms; source none
- Agent CLI pre-provider attribution:
  - Spans are selected by active turn timestamp window; timeline phase is descriptive, not a startup/turn classifier.

  | turn | pre-provider | known | unattributed | provider | timeline |
  |---|---:|---:|---:|---:|---|
  | cold | 3824 ms | 550 ms | 3274 ms | 1 ms | /Users/shakker/.kova/artifacts/kova-2026-05-18T094832Z/kova-agent-cold-warm-message-mock-openai-provider-kova-2026-05-18t094832z/openclaw/timeline.jsonl |
  | warm | 3449 ms | 507 ms | 2942 ms | 0 ms | /Users/shakker/.kova/artifacts/kova-2026-05-18T094832Z/kova-agent-cold-warm-message-mock-openai-provider-kova-2026-05-18t094832z/openclaw/timeline.jsonl |

  | turn | span | phase(s) | count | errors | clipped | max |
  |---|---|---|---:|---:|---:|---:|
  | cold | `plugins.metadata.scan` | `startup` x13 | 13 | 0 | 550 ms | 56 ms |
  | warm | `plugins.metadata.scan` | `startup` x13 | 13 | 0 | 507 ms | 58 ms |

### agent-gateway-rpc-turn sample 1

- Status: FAIL
- Cleanup: destroyed
- Artifact root: /Users/shakker/.kova/artifacts/kova-2026-05-18T094832Z/kova-agent-gateway-rpc-turn-mock-openai-provider-kova-2026-05-18t094832z
Measurements:
- startup: listening 2018ms; health 2155ms; readiness ready; gateway running; restarts 0
- health: startup p95 137ms; post-ready p95 4ms; failures 8; final failures 0; slowest startup-sample/gateway-start 137ms
- resources: peak RSS 571.1 MB; max CPU 127.1%; samples 13; roles gateway 610.9MB/106.3%, gateway-tree 610.9MB/106.3%, agent-cli 571.1MB/127.1%, agent-process 571.1MB/127.1%
- agent: turn 2963ms; cold/warm 2963ms/unknown; cold-warm delta unknown; pre-provider 2852ms; provider 4ms; metadata scans 6 (238.78ms); event-loop 0ms; polls 0; cleanup unknown; diagnosis agent-latency-attributed; leaks 0
- Agent turn stats: count 1; p95 2963ms; max 2963ms; pre-provider p95 2852ms
- agent CLI attribution: cold known unknown / unattributed unknown; warm known unknown / unattributed unknown
- plugins/runtime: missing deps 0; plugin failures 0; runtime deps unknown; warm restages unknown; warm reuse unknown
- diagnostics: timeline available; slowest span gateway.ready 262.66ms; embedded traces 0; liveness warnings 0; open spans 0 (0 required); node CPU/heap/trace 0/0/0
- Violations:
  - gateway-rpc pre-provider work dominated agent turn (96% of 2963ms)
- Agent turns:
  - gateway-rpc: total 2963ms; pre-provider 2852ms; provider 4ms; post-provider 107ms; response true
    - active window: metadata scans 6 (238.78ms total, max 55.38ms); event-loop samples 1 max 0ms
    - breakdown: pre-provider 2852ms; provider 4ms; post-provider 107ms; unknown 2852ms; source none
- Agent CLI pre-provider attribution:
  - Spans are selected by active turn timestamp window; timeline phase is descriptive, not a startup/turn classifier.

  | turn | pre-provider | known | unattributed | provider | timeline |
  |---|---:|---:|---:|---:|---|
  | gateway-rpc | 2852 ms | 238 ms | 2614 ms | 4 ms | /Users/shakker/.kova/artifacts/kova-2026-05-18T094832Z/kova-agent-gateway-rpc-turn-mock-openai-provider-kova-2026-05-18t094832z/openclaw/timeline.jsonl |

  | turn | span | phase(s) | count | errors | clipped | max |
  |---|---|---|---:|---:|---:|---:|
  | gateway-rpc | `plugins.metadata.scan` | `startup` x6 | 6 | 0 | 238 ms | 55 ms |

### gateway-session-send-turn sample 1

- Status: PASS
- Cleanup: destroyed
- Artifact root: /Users/shakker/.kova/artifacts/kova-2026-05-18T094832Z/kova-gateway-session-send-turn-mock-openai-provider-kova-2026-05-18t094832z
Measurements:
- startup: listening 1763ms; health 1948ms; readiness ready; gateway running; restarts 0
- health: startup p95 185ms; post-ready p95 4ms; failures 7; final failures 0; slowest startup-sample/gateway-start 185ms
- resources: peak RSS 694.2 MB; max CPU 102.1%; samples 15; roles gateway 694.2MB/102.1%, gateway-tree 694.2MB/102.1%, command-tree 57.4MB/0.7%, gateway-session-client 57.4MB/0.7%
- agent: turn 2168ms; cold/warm 2168ms/1231ms; cold-warm delta 937ms; pre-provider 1633ms; provider 3ms; metadata scans 1 (36.31ms); event-loop unknown; polls 7; cleanup unknown; diagnosis agent-latency-attributed; leaks 0
- Agent turn stats: count 2; p95 2121.15ms; max 2168ms; pre-provider p95 1586.65ms
- gateway session attribution: cold known 1625ms / unattributed 8ms; warm known 607ms / unattributed 99ms
- plugins/runtime: missing deps 0; plugin failures 0; runtime deps unknown; warm restages unknown; warm reuse unknown
- diagnostics: timeline available; slowest span gateway.chat_send.dispatch_inbound 1739.82ms; embedded traces 0; liveness warnings 0; open spans 0 (0 required); node CPU/heap/trace 0/0/0
- Agent turns:
  - cold: total 2168ms; pre-provider 1633ms; provider 3ms; post-provider 532ms; response true
    - gateway session: transport direct-gateway-rpc; create true; session create 57ms; send 7ms; first assistant 2168ms; matched assistant 2168ms; polls 4 (0 errors)
    - active window: metadata scans 1 (36.31ms total, max 36.31ms); event-loop samples 0 max unknown
    - breakdown: pre-provider 1633ms; provider 3ms; post-provider 532ms; unknown 1633ms; source none
  - warm: total 1231ms; pre-provider 706ms; provider 2ms; post-provider 523ms; response true
    - gateway session: transport direct-gateway-rpc; create false; session create n/a; send 99ms; first assistant 1231ms; matched assistant 1231ms; polls 3 (0 errors)
    - active window: metadata scans 0 (0ms total, max unknown); event-loop samples 0 max unknown
    - breakdown: pre-provider 706ms; provider 2ms; post-provider 523ms; unknown 706ms; source none
- Gateway session pre-provider attribution:
  - Spans are selected by active turn timestamp window; timeline phase is descriptive, not a startup/turn classifier.

  | turn | pre-provider | known | unattributed | provider | timeline |
  |---|---:|---:|---:|---:|---|
  | cold | 1633 ms | 1625 ms | 8 ms | 3 ms | /Users/shakker/.kova/artifacts/kova-2026-05-18T094832Z/kova-gateway-session-send-turn-mock-openai-provider-kova-2026-05-18t094832z/openclaw/timeline.jsonl |
  | warm | 706 ms | 607 ms | 99 ms | 2 ms | /Users/shakker/.kova/artifacts/kova-2026-05-18T094832Z/kova-gateway-session-send-turn-mock-openai-provider-kova-2026-05-18t094832z/openclaw/timeline.jsonl |

  | turn | span | phase(s) | count | errors | clipped | max |
  |---|---|---|---:|---:|---:|---:|
  | cold | `gateway.chat_send.dispatch_inbound` | `agent-turn` | 1 | 0 | 1625 ms | 1625 ms |
  | cold | `auto_reply.dispatch_reply_from_config` | `agent-turn` | 1 | 0 | 1624 ms | 1624 ms |
  | cold | `reply.run_reply_resolver` | `agent-turn` | 1 | 0 | 1567 ms | 1567 ms |
  | cold | `reply.run_prepared_reply` | `agent-turn` | 1 | 0 | 1403 ms | 1403 ms |
  | cold | `reply.run_agent_turn` | `agent-turn` | 1 | 0 | 743 ms | 743 ms |
  | cold | `reply.handle_inline_actions` | `agent-turn` | 1 | 0 | 72 ms | 72 ms |
  | warm | `auto_reply.dispatch_reply_from_config` | `agent-turn` | 1 | 0 | 607 ms | 607 ms |
  | warm | `gateway.chat_send.dispatch_inbound` | `agent-turn` | 1 | 0 | 607 ms | 607 ms |
  | warm | `reply.run_reply_resolver` | `agent-turn` | 1 | 0 | 601 ms | 601 ms |
  | warm | `reply.run_prepared_reply` | `agent-turn` | 1 | 0 | 577 ms | 577 ms |
  | warm | `reply.run_agent_turn` | `agent-turn` | 1 | 0 | 564 ms | 564 ms |
  | warm | `reply.resolve_directives` | `agent-turn` | 1 | 0 | 17 ms | 17 ms |

### openai-compatible-turn sample 1

- Status: FAIL
- Cleanup: destroyed
- Artifact root: /Users/shakker/.kova/artifacts/kova-2026-05-18T094832Z/kova-openai-compatible-turn-mock-openai-provider-kova-2026-05-18t094832z
Measurements:
- startup: listening 2017ms; health 2093ms; readiness ready; gateway running; restarts 0
- health: startup p95 76ms; post-ready p95 3ms; failures 8; final failures 0; slowest startup-sample/gateway-start 76ms
- resources: peak RSS 602.1 MB; max CPU 103.4%; samples 6; roles gateway 601.3MB/103.4%, gateway-tree 601.3MB/103.4%, command-tree 2MB/0%, openai-compatible-client 2MB/0%
- agent: turn 84ms; cold/warm 84ms/unknown; cold-warm delta unknown; pre-provider unknown; provider unknown; metadata scans 0 (0ms); event-loop unknown; polls 0; cleanup unknown; diagnosis no-provider-request; leaks 0
- Agent turn stats: count 1; p95 84ms; max 84ms; pre-provider p95 unknown
- plugins/runtime: missing deps 0; plugin failures 0; runtime deps unknown; warm restages unknown; warm reuse unknown
- diagnostics: timeline available; slowest span gateway.ready 269.01ms; embedded traces 0; liveness warnings 0; open spans 0 (0 required); node CPU/heap/trace 0/0/0
- Violations:
  - agent message command finished without a usable assistant response
  - openai-compatible agent turn did not produce the expected assistant response
  - openai-compatible agent turn response did not include expected marker KOVA_AGENT_OK
  - openai-compatible agent turn ran with mock auth but no mock provider request was captured
  - No provider request happened during the agent turn.
- Failed command: `node '/Users/shakker/WorkSpace/ShakkerNerd/OpenSource/OpenClaw/Kova'/support/run-openai...`
- Failure: {
- Agent turns:
  - openai-compatible: total 84ms; pre-provider unknown; provider unknown; post-provider unknown; response false
    - active window: metadata scans 0 (0ms total, max unknown); event-loop samples 0 max unknown
    - breakdown: pre-provider 0ms; provider 0ms; post-provider 0ms; unknown 0ms; source none

## Artifacts

- markdown-report: /Users/shakker/.kova/reports/kova-2026-05-18T094832Z-smoke.md
- json-report: /Users/shakker/.kova/reports/kova-2026-05-18T094832Z-smoke.json
- summary-json: /Users/shakker/.kova/reports/kova-2026-05-18T094832Z-smoke.summary.json
- collector-root release-runtime-startup#1: /Users/shakker/.kova/artifacts/kova-2026-05-18T094832Z/kova-release-runtime-startup-fresh-kova-2026-05-18t094832z
- collector-root fresh-install#1: /Users/shakker/.kova/artifacts/kova-2026-05-18T094832Z/kova-fresh-install-fresh-kova-2026-05-18t094832z
- collector-root bundled-runtime-deps#1: /Users/shakker/.kova/artifacts/kova-2026-05-18T094832Z/kova-bundled-runtime-deps-missing-plugin-index-kova-2026-05-18t094832z
- collector-root plugin-lifecycle#1: /Users/shakker/.kova/artifacts/kova-2026-05-18T094832Z/kova-plugin-lifecycle-stale-runtime-deps-kova-2026-05-18t094832z
- collector-root bundled-plugin-startup#1: /Users/shakker/.kova/artifacts/kova-2026-05-18T094832Z/kova-bundled-plugin-startup-fresh-kova-2026-05-18t094832z
- collector-root gateway-performance#1: /Users/shakker/.kova/artifacts/kova-2026-05-18T094832Z/kova-gateway-performance-many-bundled-plugins-kova-2026-05-18t094832z
- collector-root agent-cold-warm-message#1: /Users/shakker/.kova/artifacts/kova-2026-05-18T094832Z/kova-agent-cold-warm-message-mock-openai-provider-kova-2026-05-18t094832z
- collector-root agent-gateway-rpc-turn#1: /Users/shakker/.kova/artifacts/kova-2026-05-18T094832Z/kova-agent-gateway-rpc-turn-mock-openai-provider-kova-2026-05-18t094832z
- collector-root gateway-session-send-turn#1: /Users/shakker/.kova/artifacts/kova-2026-05-18T094832Z/kova-gateway-session-send-turn-mock-openai-provider-kova-2026-05-18t094832z
- 1 additional artifact reference(s) omitted from Markdown. See summary JSON.

